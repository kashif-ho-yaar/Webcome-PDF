package com.example.logic

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import com.example.data.Screenshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class PdfGenerator(private val context: Context) {

    suspend fun generatePdf(screenshots: List<Screenshot>): String? = withContext(Dispatchers.IO) {
        if (screenshots.isEmpty()) return@withContext null

        val pdfDocument = PdfDocument()
        
        screenshots.forEachIndexed { index, screenshot ->
            val file = File(screenshot.filePath)
            if (file.exists()) {
                val bitmap = BitmapFactory.decodeFile(screenshot.filePath)
                if (bitmap != null) {
                    val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, index + 1).create()
                    val page = pdfDocument.startPage(pageInfo)
                    val canvas = page.canvas
                    canvas.drawBitmap(bitmap, 0f, 0f, null)
                    pdfDocument.finishPage(page)
                }
            }
        }

        val pdfFile = File(context.filesDir, "pdfs").apply { if (!exists()) mkdirs() }
        val fileName = "doc_${System.currentTimeMillis()}.pdf"
        val outFile = File(pdfFile, fileName)

        try {
            pdfDocument.writeTo(FileOutputStream(outFile))
            pdfDocument.close()
            outFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
