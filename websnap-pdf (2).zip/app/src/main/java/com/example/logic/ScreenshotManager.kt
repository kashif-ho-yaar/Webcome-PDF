package com.example.logic

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.data.Screenshot
import com.example.data.ScreenshotDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.*

class ScreenshotManager(
    private val context: Context,
    private val screenshotDao: ScreenshotDao
) {
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO)

    fun captureLinks(urls: List<String>, onProgress: (Int, Int) -> Unit, onComplete: () -> Unit) {
        val total = urls.size
        var current = 0
        val maxConcurrent = 5
        var active = 0
        val queue = LinkedList(urls)

        fun processNext() {
            if (active == 0 && queue.isEmpty()) {
                onComplete()
                return
            }

            while (active < maxConcurrent && queue.isNotEmpty()) {
                val url = queue.poll() ?: break
                active++
                captureSingleLink(url) {
                    current++
                    onProgress(current, total)
                    active--
                    processNext()
                }
            }
        }

        handler.post {
            processNext()
        }
    }

    private fun captureSingleLink(url: String, onCaptured: () -> Unit) {
        val webView = WebView(context)
        // Enable JS for better snapshots
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        
        // Ensure webview has a physical size so that it renders the bitmap properly headless
        val widthSpec = android.view.View.MeasureSpec.makeMeasureSpec(1080, android.view.View.MeasureSpec.EXACTLY)
        val heightSpec = android.view.View.MeasureSpec.makeMeasureSpec(1920, android.view.View.MeasureSpec.EXACTLY)
        webView.measure(widthSpec, heightSpec)
        webView.layout(0, 0, webView.measuredWidth, webView.measuredHeight)

        var hasCaptured = false

        fun captureNow() {
            if (hasCaptured) return
            hasCaptured = true
            
            webView.measure(widthSpec, heightSpec)
            webView.layout(0, 0, webView.measuredWidth, webView.measuredHeight)

            val bitmap = Bitmap.createBitmap(webView.width, webView.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            webView.draw(canvas)
            
            saveBitmap(url, bitmap)
            webView.destroy()
            onCaptured()
        }

        fun checkContentAndCapture(attempts: Int = 0) {
            if (hasCaptured) return
            // Wait for JS to run and render some text, meaning the page is visible.
            webView.evaluateJavascript("(function() { return document.body && document.body.innerText.trim().length > 0; })();") { result ->
                if (result == "true") {
                    // Page has text, it's not totally blank. We can capture it safely.
                    // Wait a moment for any final rendering/animations
                    handler.postDelayed({
                        captureNow()
                    }, 400)
                } else if (attempts < 10) { // Up to 3.5 seconds wait max using 350ms delay
                    handler.postDelayed({
                        checkContentAndCapture(attempts + 1)
                    }, 350)
                } else {
                    // Maximum attempts reached and page is still blank.
                    // Do not take a screenshot, just abort and move to next.
                    hasCaptured = true
                    webView.destroy()
                    onCaptured()
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, urlStr: String?) {
                // Once native page load finishes, start checking for text content
                handler.postDelayed({
                    checkContentAndCapture()
                }, 200)
            }
            
            override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                if (!hasCaptured) {
                    hasCaptured = true
                    webView.destroy()
                    onCaptured() // Skip or handle error
                }
            }
        }

        webView.loadUrl(url)
    }

    private fun saveBitmap(url: String, bitmap: Bitmap) {
        scope.launch {
            try {
                // Compress once to a byte array to avoid doing heavy compression twice
                val stream = java.io.ByteArrayOutputStream()
                val format = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    @Suppress("DEPRECATION")
                    Bitmap.CompressFormat.WEBP
                }
                bitmap.compress(format, 80, stream) // 80 quality is faster and smaller but still good
                val byteArray = stream.toByteArray()
                bitmap.recycle() // Free memory as soon as possible

                val fileName = "snap_${System.currentTimeMillis()}"
                val file = File(context.filesDir, "screenshots").apply { if (!exists()) mkdirs() }
                val screenshotFile = File(file, "$fileName.webp")

                // Write bytes to internal file
                FileOutputStream(screenshotFile).use { out ->
                    out.write(byteArray)
                }

                // Save to device public gallery (MediaStore) reusing the byte array
                val contentValues = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "$fileName.webp")
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "image/webp")
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_PICTURES + "/Snapshots")
                        put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                }
                
                val resolver = context.contentResolver
                val uri = resolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                uri?.let { destUri ->
                    resolver.openOutputStream(destUri)?.use { out ->
                        out.write(byteArray)
                    }
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        contentValues.clear()
                        contentValues.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0)
                        resolver.update(destUri, contentValues, null, null)
                    }
                }

                val screenshot = Screenshot(
                    url = url,
                    filePath = screenshotFile.absolutePath
                )
                screenshotDao.insertScreenshot(screenshot)
            } catch (e: Exception) {
                e.printStackTrace()
                // Ensure recycle on failure just in case
                if (!bitmap.isRecycled) {
                    bitmap.recycle()
                }
            }
        }
    }
}
