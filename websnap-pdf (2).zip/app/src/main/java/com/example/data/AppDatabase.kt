package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "screenshots")
data class Screenshot(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val url: String,
    val filePath: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface ScreenshotDao {
    @Query("SELECT * FROM screenshots ORDER BY timestamp DESC")
    fun getAllScreenshots(): Flow<List<Screenshot>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScreenshot(screenshot: Screenshot)

    @Delete
    suspend fun deleteScreenshot(screenshot: Screenshot)
    
    @Query("SELECT * FROM screenshots WHERE id IN (:ids)")
    suspend fun getScreenshotsByIds(ids: List<Int>): List<Screenshot>
}

@Database(entities = [Screenshot::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun screenshotDao(): ScreenshotDao
}
