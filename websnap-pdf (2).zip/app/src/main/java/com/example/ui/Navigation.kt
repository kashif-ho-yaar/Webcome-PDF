package com.example.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.serialization.Serializable

@Serializable
sealed class Screen {
    @Serializable
    data object Links : Screen()
    
    @Serializable
    data object Gallery : Screen()

    @Serializable
    data object Settings : Screen()

    @Serializable
    data class WebLogin(val url: String) : Screen()

    val title: String
        get() = when (this) {
            is Links -> "Links"
            is Gallery -> "Gallery"
            is Settings -> "Settings"
            is WebLogin -> "Login"
        }

    val icon: ImageVector
        get() = when (this) {
            is Links -> Icons.AutoMirrored.Filled.List
            is Gallery -> Icons.Default.PhotoLibrary
            is Settings -> Icons.Default.Settings
            is WebLogin -> Icons.Default.Settings
        }
}
