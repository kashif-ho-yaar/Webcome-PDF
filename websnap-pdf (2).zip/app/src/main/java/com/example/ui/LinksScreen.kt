package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun LinksScreen(viewModel: MainViewModel) {
    var text by remember { mutableStateOf("https://example.com\nhttps://wikipedia.org\nhttps://github.com\nhttps://developer.android.com") }
    val isCapturing by viewModel.isCapturing.collectAsStateWithLifecycle()
    val progress by viewModel.captureProgress.collectAsStateWithLifecycle()
    val showCongrats by viewModel.showCongrats.collectAsStateWithLifecycle()
    val focusManager = LocalFocusManager.current

    if (showCongrats) {
        val scale = remember { androidx.compose.animation.core.Animatable(0f) }
        LaunchedEffect(Unit) {
            scale.animateTo(
                targetValue = 1f,
                animationSpec = androidx.compose.animation.core.spring(
                    dampingRatio = androidx.compose.animation.core.Spring.DampingRatioMediumBouncy,
                    stiffness = androidx.compose.animation.core.Spring.StiffnessLow
                )
            )
        }

        AlertDialog(
            onDismissRequest = { viewModel.dismissCongrats() },
            title = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = Color(0xFF4CAF50),
                        modifier = Modifier
                            .size(80.dp)
                            .scale(scale.value)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "Extraction Complete", textAlign = TextAlign.Center)
                }
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Thanks for using, Al'Mudafioon Screenshot Panel And Keep working On",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "ختم نبوت",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.dismissCongrats() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Awesome!")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Paste Many Links",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 200.dp),
            placeholder = { Text("https://google.com\nhttps://github.com\n...") },
            label = { Text("URLs (one per line)") },
            enabled = !isCapturing
        )

        Spacer(modifier = Modifier.height(24.dp))

        if (isCapturing) {
            val (current, total) = progress
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(modifier = Modifier.height(8.dp))
                Text("Capturing $current of $total...", style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(
                    progress = if (total > 0) current.toFloat() / total else 0f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                )
            }
        } else {
            Button(
                onClick = {
                    focusManager.clearFocus()
                    viewModel.startCapture(text)
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = text.isNotBlank()
            ) {
                Text("Start Capturing")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Note: Performance depends on internet speed and complexity of pages.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.secondary
        )
    }
}
