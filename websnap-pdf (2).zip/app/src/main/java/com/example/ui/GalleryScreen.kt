package com.example.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items as listItems
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.Screenshot
import java.io.File

@Composable
fun GalleryScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Screenshots", "PDFs")

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title) }
                )
            }
        }

        when (selectedTab) {
            0 -> ScreenshotGrid(viewModel)
            1 -> PdfList(viewModel)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ScreenshotGrid(viewModel: MainViewModel) {
    val screenshots by viewModel.screenshots.collectAsStateWithLifecycle(initialValue = emptyList())
    val selectedIds by viewModel.selectedScreenshotIds.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        if (screenshots.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${selectedIds.size} Selected",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row {
                    if (selectedIds.size < screenshots.size) {
                        TextButton(onClick = { viewModel.selectAll(screenshots.map { it.id }) }) {
                            Text("Select All")
                        }
                    }
                    if (selectedIds.isNotEmpty()) {
                        TextButton(onClick = { viewModel.clearSelection() }) {
                            Text("Clear")
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.fillMaxSize().weight(1f)) {
            if (screenshots.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No screenshots are available.", color = MaterialTheme.colorScheme.secondary)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(150.dp),
                    contentPadding = PaddingValues(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    gridItems(screenshots) { screenshot ->
                        val isSelected = selectedIds.contains(screenshot.id)
                        Card(
                            modifier = Modifier
                                .padding(4.dp)
                                .aspectRatio(0.7f)
                                .combinedClickable(
                                    onClick = { 
                                        // Just make clicking toggle selection all the time to make it easy
                                        viewModel.toggleSelection(screenshot.id)
                                    },
                                    onLongClick = {
                                        viewModel.toggleSelection(screenshot.id)
                                    }
                                ),
                            elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 8.dp else 2.dp),
                            border = if (isSelected) CardDefaults.outlinedCardBorder().copy(width = 3.dp, brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary)) else null
                        ) {
                            Box {
                                AsyncImage(
                                    model = File(screenshot.filePath),
                                    contentDescription = screenshot.url,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .fillMaxWidth()
                                        .background(
                                            brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                                            )
                                        )
                                        .padding(8.dp)
                                        .padding(end = 36.dp) 
                                ) {
                                    Text(
                                        text = screenshot.url,
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Selected",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(8.dp)
                                            .size(32.dp)
                                            .background(Color.White, shape = MaterialTheme.shapes.small)
                                    )
                                }
                                
                                IconButton(
                                    onClick = { viewModel.deleteScreenshot(screenshot) },
                                    modifier = Modifier.align(Alignment.BottomEnd)
                                ) {
                                    Icon(
                                        Icons.Default.Delete, 
                                        contentDescription = "Delete", 
                                        tint = Color.White.copy(alpha = 0.7f),
                                        modifier = Modifier.background(Color.Black.copy(alpha = 0.4f), shape = MaterialTheme.shapes.small).padding(4.dp)
                                    )
                                }
                            }
                        }
                    }
                } // Close LazyVerticalGrid
            } // Close else block

            if (selectedIds.isNotEmpty()) {
                FloatingActionButton(
                    onClick = { viewModel.generatePdfFromSelection() },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 16.dp),
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Row(modifier = Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Generate PDF (${selectedIds.size})")
                    }
                }
            }
        }
    }
}

@Composable
fun PdfList(viewModel: MainViewModel) {
    val pdfs by viewModel.generatedPdfs.collectAsStateWithLifecycle()

    if (pdfs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No PDFs generated yet", color = MaterialTheme.colorScheme.secondary)
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listItems(pdfs) { pdf ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { viewModel.openPdf(pdf.absolutePath) }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(pdf.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${pdf.length() / 1024} KB", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
