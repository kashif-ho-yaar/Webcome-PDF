package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Web

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onNavigateToLogin: (String) -> Unit) {
    val context = LocalContext.current
    var bugReportText by remember { mutableStateOf("") }
    var customLoginUrl by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopAppBar(
            title = { Text("Settings") },
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Check Updates
        Button(
            onClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://avidore-mdf.lovable.app"))
                context.startActivity(intent)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.SystemUpdate, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Check Updates")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Logins
        Text(
            text = "Platform Login (to prevent auth issues)",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(modifier = Modifier.height(8.dp))

        val socialPlatforms = listOf(
            "Facebook" to "https://m.facebook.com",
            "Twitter / X" to "https://mobile.twitter.com/login",
            "LinkedIn" to "https://www.linkedin.com/login",
            "Instagram" to "https://www.instagram.com/accounts/login/"
        )

        socialPlatforms.forEach { (name, url) ->
            OutlinedButton(
                onClick = { onNavigateToLogin(url) },
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Icon(Icons.Default.Login, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Login to $name")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = customLoginUrl,
                onValueChange = { customLoginUrl = it },
                label = { Text("Custom URL Login") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(onClick = {
                if (customLoginUrl.isNotBlank()) {
                    val url = if (customLoginUrl.startsWith("http")) customLoginUrl else "https://$customLoginUrl"
                    onNavigateToLogin(url)
                }
            }) {
                Icon(Icons.Default.Web, contentDescription = "Open Custom URL")
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(32.dp))

        Text(
            text = "Report Bugs / Crash / Lags",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = bugReportText,
            onValueChange = { bugReportText = it },
            label = { Text("Describe the issue") },
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp),
            maxLines = 5
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val phoneNumber = "+923288862114" // Assuming Pakistani number given the 03XX format
                val url = "https://api.whatsapp.com/send?phone=$phoneNumber&text=${Uri.encode(bugReportText)}"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                try {
                    context.startActivity(intent)
                } catch (e: Exception) {
                    // Fallback to general dialer or web intent if WhatsApp is not installed
                    val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/923288862114?text=${Uri.encode(bugReportText)}"))
                    context.startActivity(webIntent)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.BugReport, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Send Report via WhatsApp")
        }
    }
}
