package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.Screenshot
import com.example.logic.PdfGenerator
import com.example.logic.ScreenshotManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val db = Room.databaseBuilder(
        application,
        AppDatabase::class.java, "linksnap-db"
    ).build()
    
    private val screenshotDao = db.screenshotDao()
    private val screenshotManager = ScreenshotManager(application, screenshotDao)
    private val pdfGenerator = PdfGenerator(application)

    val screenshots = screenshotDao.getAllScreenshots()

    private val _isCapturing = MutableStateFlow(false)
    val isCapturing: StateFlow<Boolean> = _isCapturing.asStateFlow()

    private val _showCongrats = MutableStateFlow(false)
    val showCongrats: StateFlow<Boolean> = _showCongrats.asStateFlow()

    private val _captureProgress = MutableStateFlow(Pair(0, 0))
    val captureProgress: StateFlow<Pair<Int, Int>> = _captureProgress.asStateFlow()

    private val _generatedPdfs = MutableStateFlow<List<File>>(emptyList())
    val generatedPdfs: StateFlow<List<File>> = _generatedPdfs.asStateFlow()

    private val _selectedScreenshotIds = MutableStateFlow<Set<Int>>(emptySet())
    val selectedScreenshotIds: StateFlow<Set<Int>> = _selectedScreenshotIds.asStateFlow()

    private val _pdfPathToOpen = MutableStateFlow<String?>(null)
    val pdfPathToOpen: StateFlow<String?> = _pdfPathToOpen.asStateFlow()

    init {
        loadPdfs()
    }

    fun startCapture(urlsRaw: String) {
        val urls = urlsRaw.lines().filter { it.isNotBlank() }.map { it.trim() }
        if (urls.isEmpty()) return

        _isCapturing.value = true
        _showCongrats.value = false
        screenshotManager.captureLinks(
            urls = urls,
            onProgress = { current, total ->
                _captureProgress.value = current to total
            },
            onComplete = {
                _isCapturing.value = false
                _showCongrats.value = true
            }
        )
    }

    fun dismissCongrats() {
        _showCongrats.value = false
    }

    fun toggleSelection(id: Int) {
        val current = _selectedScreenshotIds.value.toMutableSet()
        if (current.contains(id)) current.remove(id) else current.add(id)
        _selectedScreenshotIds.value = current
    }

    fun selectAll(ids: List<Int>) {
        _selectedScreenshotIds.value = ids.toSet()
    }

    fun clearSelection() {
        _selectedScreenshotIds.value = emptySet()
    }

    fun generatePdfFromSelection() {
        viewModelScope.launch {
            val ids = _selectedScreenshotIds.value.toList()
            if (ids.isEmpty()) return@launch
            
            val selectedScreenshots = screenshotDao.getScreenshotsByIds(ids)
            val path = pdfGenerator.generatePdf(selectedScreenshots)
            if (path != null) {
                loadPdfs()
                clearSelection()
            }
        }
    }

    fun loadPdfs() {
        viewModelScope.launch {
            val pdfDir = File(getApplication<Application>().filesDir, "pdfs")
            if (pdfDir.exists()) {
                _generatedPdfs.value = pdfDir.listFiles()?.filter { it.extension == "pdf" }?.sortedByDescending { it.lastModified() } ?: emptyList()
            }
        }
    }
    
    fun deleteScreenshot(screenshot: Screenshot) {
        viewModelScope.launch {
            screenshotDao.deleteScreenshot(screenshot)
            File(screenshot.filePath).delete()
        }
    }
    
    fun openPdf(path: String) {
        _pdfPathToOpen.value = path
    }
    
    fun consumePdfOpen() {
        _pdfPathToOpen.value = null
    }
}
